package dzikir.yuk.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.listview);

        String[] title=getResources().getStringArray(R.array.title_book);
        final String[] details=getResources().getStringArray(R.array.detail_book);

        ArrayAdapter<String>arrayAdapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,title);
        listView.setAdapter(arrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                String iss=details[i];
                Intent ii=new Intent(MainActivity.this,detailsactivity.class);
                    ii.putExtra("detail",iss);
                    startActivity(ii);
            }
        });


    }

}